# Mandelbrot Class

This is a package for mandelbrot class with certain computational and plotting functions. GitHub repository: [class_Mandelbrot](https://github.com/jiangmengtian/class_Mandelbrot)

# Dependence

NumPy and Matplotlib are required.

# Description of Catalog Stucture

Mandelbrot/
├── LICENSE
├── pyproject.toml
├── README.md
├── pytest.ini
├── src/
│   └── mandelbrotpy/
│       ├── __init__.py
│       └── Mandelbrot.py
└── tests/

# Instruction

The functions are based on [escape time algorithms](https://en.wikipedia.org/wiki/Plotting_algorithms_for_the_Mandelbrot_set#Escape_time_algorithm) and [coloring algorithms](https://en.wikipedia.org/wiki/Plotting_algorithms_for_the_Mandelbrot_set#Coloring_algorithms). The followings are instruction for these functions.
    + getIters()
    Compute the iterations for each pixel(a complex number) before it exceeds the bound.
    + getColor()
    Compute the color value rescaled from iterations for each pixed.
    + histColor()
    A coloring algorithm to visualize the result.
    + smoothColor()
    An optimized coloring algorithm blurring the color bands.

An example is shown [here](https://github.com/jiangmengtian/class_Mandelbrot/blob/main/example.ipynb).